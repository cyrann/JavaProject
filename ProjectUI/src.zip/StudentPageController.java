import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class StudentPageController {

    @FXML
    ImageView photo;

    @FXML
    TextField studentID;

    @FXML
    TextField first;

    @FXML
    TextField last;

    @FXML
    DatePicker dob;

    @FXML
    TextField gender;

    @FXML
    TextField program;

    @FXML
    ChoiceBox<String> reason;

    @FXML
    Button clear;

    @FXML
    Button save;

    @FXML
    public void clearText(){
        studentID.setText("");
        last.setText("");
        first.setText("");
        dob.getEditor().clear();
        gender.setText("");
        program.setText("");
        reason.setValue("no specific reason");
    }

    @FXML
    public void saveText(){

    }

    @FXML
    public void initialize(){
         reason.setItems(FXCollections.observableArrayList(
                 "no specific reason", "stapler", "tuition fees", "complaints", "collect assignments", "meet prople", "others"));
         reason.setValue("no specific reason");
         photo.setImage(new Image("https://www.trespass.com/media/catalog/product/cache/6/small_image/256x/9df78eab33525d08d6e5fb8d27136e95/c/o/collar_1.jpg"));
    }
}
