
public class Guest {

    char guestID;
    String first;
    String last;
    String gender;
    String reason;
}
